using UnityEngine;

public class ReturnToLobby : MonoBehaviour
{
    public void ReturnToTheLobby()
    {
        NetworkManager.ReturnToLobby();
    }
}
